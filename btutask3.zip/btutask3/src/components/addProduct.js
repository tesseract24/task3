import React, { useState } from "react";
import { Button ,Card, Form } from "react-bootstrap"
import { db } from "../firebase";

const AddProduct = () => {
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [category, setCategory] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();

    db.collection("product")
      .add({
        name: name,
        price: price,
        category : category
      })
      .then(() => {
        alert("Your product has been added");
      })
      .catch((error) => {
        alert(error.message);
      });

    setName("");
    setPrice("");
    setCategory("");
  };

  return (
    <form className="form" onSubmit={handleSubmit}>
    <Card>
        <Card.Body>
        <h2 className="text-center mb-4">Add Product</h2>

        <Form onSubmit={handleSubmit}>

            <Form.Group id="Category">
                <Form.Label>Category</Form.Label>
                <Form.Control placeholder="Category" value={category} onChange={(e) => setCategory(e.target.value)} type="text"  required />
            </Form.Group>

            <Form.Group id="Name">
                <Form.Label>Name</Form.Label>
                <Form.Control placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} type="text"  required />
            </Form.Group>

            <Form.Group id="price">
                <Form.Label>Price</Form.Label>
                <Form.Control placeholder="Price" value={price} onChange={(e) => setPrice(e.target.value)} type="number"  required />
            </Form.Group>
                <Button  className="w-100" type="submit">
            Add Product
            </Button>
        </Form>
        </Card.Body>
    </Card>
    </form>
  );
};

export default AddProduct;