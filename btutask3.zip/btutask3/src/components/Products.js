import React, { useState } from 'react';
import { Form } from 'react-bootstrap';


const Category1 = 'Category1';
const Category2 = 'Category2';
const Category3 = 'Category3';

export default function Products({ setCart, cart }) {
  const [products] = useState([
    {
      category: Category2,
      name: 'AA Battery',
      cost: 2.99,
      image:
        'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQ5-QAul_NfAs-s0XW9M087xWyPOGWvbfYjmqSl0QXabZRSYoid47i7kISiAteyIh0YOci5mtQ&usqp=CAc',
    },
    {
      category: Category1,
      name: 'Blanket',
      cost: 19.99,
      image:
        'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSpwdYDmUL_ZEqhLV7ZWRdQAU7DGcGaxtCt7SrTlL9umrQs2Un7rj9Nbb9Vq01RtEfA0eAVmdt-&usqp=CAc',
    },
    {
      category: Category1,
      name: 'pen',
      cost: 12.99,
      image:
        'https://www.pngkey.com/png/detail/21-213344_bic-pen-png-image-ballpoint-pen.png',
    },
    {
      category: Category1,
      name: 'book',
      cost: 5.99,
      image:
        'https://png.pngitem.com/pimgs/s/7-77375_computer-icons-book-clip-art-stack-of-books.png',
    },
  ]);

  const addToCart = (product) => {
    let newCart = [...cart];
    let itemInCart = newCart.find(
      (item) => product.name === item.name
    );
    if (itemInCart) {
      itemInCart.quantity++;
    } else {
      itemInCart = {
        ...product,
        quantity: 1,
      };
      newCart.push(itemInCart);
    }
    setCart(newCart);
  };

  const [category, setCategory] = useState(Category1);

  const getProductsInCategory = () => {
    return products.filter(
      (product) => product.category === category
    );
  };

  return (
    <>
      <h1>Products</h1>
      <p>Select a category</p>
      <Form.Control
        as="select"
        className="btn btn-secondary dropdown-toggle"
        id="inlineFormCustomSelect"
        custom
        onChange={(e) => setCategory(e.target.value)}
      >
        <option value={Category1}>{Category1}</option>
        <option value={Category2}>{Category2}</option>
        <option value={Category3}>{Category3}</option>
      </Form.Control>



      <div class="album py-5">
        <div class="container">
          <div class="row">

              {getProductsInCategory().map((product, idx) => (
                <div class="col-md-4">
                  <div class=" mb-4 box-shadow">
                    <div className="product" key={idx}>
                      <img  className="card-img-top" style={{ maxWidth: "200px" }} src={product.image} alt={product.name} />
                      <h3 className="card-text">{product.name}</h3>
                      <h4 className="card-text">${product.cost}</h4>
                      <button  className="btn btn-secondary"onClick={() => addToCart(product)}>
                        Add to Cart
                      </button>
                    </div>
                  </div>
                </div>
              ))}

          </div>
        </div>
      </div>
    </>
  );
}