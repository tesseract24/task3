import firebase from "firebase/app"
import 'firebase/firestore';
import "firebase/auth"

const app = firebase.initializeApp({
    apiKey: "AIzaSyA7Y1nEFgrcSgZd-l1W6YEGBE7Zu3N-N5c",
    authDomain: "reacttask3.firebaseapp.com",
    projectId: "reacttask3",
    storageBucket: "reacttask3.appspot.com",
    messagingSenderId: "931283494549",
    appId: "1:931283494549:web:205f1887a11bd27fcb5d9c"
})

const db = app.firestore();
const auth = app.auth()

export {db , auth};
export default app
